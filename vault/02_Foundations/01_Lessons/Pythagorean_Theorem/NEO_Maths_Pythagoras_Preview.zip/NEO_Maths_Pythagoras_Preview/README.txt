NEO MATHEMATICS — PYTHAGOREAN THEOREM LOCAL PREVIEW

1. Extract the complete ZIP file.
2. Open the extracted folder.
3. Double-click START_HERE.html.
4. If asked, choose Chrome, Edge, Firefox or Safari.

Keep the Lessons and Guidance folders beside START_HERE.html so that all links work.

This is a local preview. It does not alter or publish anything to GitHub.
